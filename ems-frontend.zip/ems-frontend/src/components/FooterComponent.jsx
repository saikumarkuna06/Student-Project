import React from 'react'

const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <span>All right reserved 2024 by javasai</span>
        </footer>
    </div>
  )
}

export default FooterComponent